package com.example.note;

import android.app.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.text.method.ScrollingMovementMethod;
import android.text.util.Linkify;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.note.bean.NoteBean;
import com.example.note.util.DataBaseHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class LookActivity extends Activity {

    private TextView tv_title;
    private TextView tv_content;
    private TextView tv_date;
    private TextView tv_time;
    private LinearLayout ll_styles;
    private DataBaseHelper db = null;
    private NoteBean note;

    GridView image_grid_view;
    GridViewAdapter adapter;
    private List<String> datas = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.look_activity);
        initView();
        init();

    }

    private void initView() {
        tv_date = (TextView) findViewById(R.id.tv_date);
        tv_time = (TextView) findViewById(R.id.tv_time);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_content = (TextView) findViewById(R.id.tv_content);
        ll_styles = (LinearLayout) findViewById(R.id.ll_styles);
        image_grid_view = (GridView) findViewById(R.id.image_grid_view);
    }

    private void init() {
        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        db = new DataBaseHelper(LookActivity.this);
        note = db.getNote(id);
        tv_date.setText(note.getDate());
        tv_time.setText(note.getTime());
        tv_title.setText(note.getTitle());

        tv_content.setText("        " + note.getContent());

        List<String> types = note.getTypes();
        if (types != null) {
            for (int i = 0; i < types.size(); i++) {
                TextView tv = new TextView(getApplicationContext());
                tv.setText(types.get(i));
                tv.setTextColor(Color.parseColor("#f3f3f3"));
                tv.setTextSize(18);
                tv.setPadding(10, 5, 10, 5);
                tv.setBackgroundResource(R.drawable.bg_gray);
                tv.setTextAppearance(getApplication(), R.style.mark_style_tmp);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
                lp.gravity = Gravity.CENTER;
                lp.setMargins(5, 5, 5, 5);
                tv.setLayoutParams(lp);
                ll_styles.addView(tv);
            }
        }

//        tv_content.setAutoLinkMask(Linkify.ALL);
//        tv_content.setMovementMethod(LinkMovementMethod.getInstance());
//        tv_content.setMovementMethod(ScrollingMovementMethod.getInstance());
        datas.addAll(note.getPics());
//        for (int i = 0; i < datas.size(); i++) {
//            ImageView iv = new ImageView(this);
//            iv.setImageURI(Uri.fromFile(new File(datas.get(i))));
//            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(300, 300);
//            lp.gravity = Gravity.CENTER;
//            lp.setMargins(5, 5, 5, 5);
//            iv.setLayoutParams(lp);
//        }
        adapter = new GridViewAdapter();
        image_grid_view.setAdapter(adapter);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((datas.size()+1)*200, 300);
        image_grid_view.setLayoutParams(params);
        image_grid_view.setNumColumns((datas.size()));
    }

    private class GridViewAdapter extends BaseAdapter {
        private ViewHolder mViewHolder;


        @Override
        public int getCount() {
            return datas.size();
        }

        @Override
        public Object getItem(int position) {
            return datas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pic_item, parent, false);
                mViewHolder = new ViewHolder();
                mViewHolder.mImageView = (ImageView) convertView.findViewById(R.id.imageView);
                convertView.setTag(mViewHolder);
            } else {
                mViewHolder = (ViewHolder) convertView.getTag();
            }

            mViewHolder.mImageView.setImageURI(Uri.fromFile(new File(datas.get(position))));
//            mViewHolder.mImageView.setImageBitmap(mBitmaps.get(position));
            return convertView;
        }

        public class ViewHolder {
            public ImageView mImageView;
        }
    }
}
