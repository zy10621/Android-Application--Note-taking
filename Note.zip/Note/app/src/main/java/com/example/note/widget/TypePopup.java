package com.example.note.widget;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.example.note.R;

/**
 * Created by 0 on 2016/1/28.
 */
public class TypePopup extends PopupWindow implements View.OnClickListener {
    private View conentView;
    private Context context;

    public TypePopup(Activity context) {

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.context = context;
        conentView = inflater.inflate(R.layout.type_popu, null);
        this.setContentView(conentView);
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
        this.setHeight(ViewGroup.LayoutParams.MATCH_PARENT);
        this.setFocusable(true);
        this.setOutsideTouchable(true);
        this.update();
        ColorDrawable dw = new ColorDrawable(0xffeeaa);
        this.setBackgroundDrawable(dw);
        setAnimationStyle(android.R.style.Animation_Dialog);
        setUpViews(conentView);
        setUpListener();
    }

    private TextView tv_type1;
    private TextView tv_type2;
    private TextView tv_type3;
    private TextView tv_type4;
    private TextView tv_type5;
    private TextView tv_type6;
    private TextView tv_type7;
    private TextView tv_type8;
    private TextView tv_type9;

    private void setUpViews(View view) {
        tv_type1 = (TextView) view.findViewById(R.id.tv_type1);
        tv_type2 = (TextView) view.findViewById(R.id.tv_type2);
        tv_type3 = (TextView) view.findViewById(R.id.tv_type3);
        tv_type4 = (TextView) view.findViewById(R.id.tv_type4);
        tv_type5 = (TextView) view.findViewById(R.id.tv_type5);
        tv_type6 = (TextView) view.findViewById(R.id.tv_type6);
        tv_type7 = (TextView) view.findViewById(R.id.tv_type7);
        tv_type8 = (TextView) view.findViewById(R.id.tv_type8);
        tv_type9 = (TextView) view.findViewById(R.id.tv_type9);

    }

    private void setUpListener() {
        tv_type1.setOnClickListener(this);
        tv_type2.setOnClickListener(this);
        tv_type3.setOnClickListener(this);
        tv_type4.setOnClickListener(this);
        tv_type5.setOnClickListener(this);
        tv_type6.setOnClickListener(this);
        tv_type7.setOnClickListener(this);
        tv_type8.setOnClickListener(this);
        tv_type9.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        typeClick.click(((TextView) view).getText().toString());
        dismiss();
    }

    private onTypeClick typeClick;

    public void setTypeClick(onTypeClick typeClick) {
        this.typeClick = typeClick;
    }

    public interface onTypeClick {
        public void click(String str);
    }
}
