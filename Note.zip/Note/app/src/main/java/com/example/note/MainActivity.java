package com.example.note;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.note.bean.NoteBean;
import com.example.note.util.DataBaseHelper;

import java.util.List;

public class MainActivity extends Activity implements OnClickListener{
    private ListView listVIew;
    private ImageView iv_add;
    private TextView empty_view;
    private DataBaseHelper db = new DataBaseHelper(MainActivity.this);
    private List<NoteBean> lists;
    private NoteAdapter adapter;

    private TextView tv_type1;
    private TextView tv_type2;
    private TextView tv_type3;
    private TextView tv_type4;
    private TextView tv_type5;
    private TextView tv_type6;
    private TextView tv_type7;
    private TextView tv_type8;
    private TextView tv_type9;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initListener();

    }

    private void initView() {
        listVIew = (ListView) findViewById(android.R.id.list);
        iv_add = (ImageView) findViewById(R.id.iv_add);
        empty_view = (TextView) findViewById(R.id.empty_view);
        listVIew.setEmptyView(empty_view);

        tv_type1 = (TextView) findViewById(R.id.tv_type1);
        tv_type2 = (TextView) findViewById(R.id.tv_type2);
        tv_type3 = (TextView) findViewById(R.id.tv_type3);
        tv_type4 = (TextView) findViewById(R.id.tv_type4);
        tv_type5 = (TextView) findViewById(R.id.tv_type5);
        tv_type6 = (TextView) findViewById(R.id.tv_type6);
        tv_type7 = (TextView) findViewById(R.id.tv_type7);
        tv_type8 = (TextView) findViewById(R.id.tv_type8);
        tv_type9 = (TextView) findViewById(R.id.tv_type9);

    }

    private void init() {
        adapter = new NoteAdapter();
        lists = db.getLists();
        adapter.setNoteBeans(lists);
        listVIew.setAdapter(adapter);
    }

    private void initListener() {
        listVIew.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int i, long l) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Operation")
                        .setItems(R.array.operation, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which) {
                                    case 0:
                                        golook(i);
                                        break;
                                    case 1:
                                        gochang(i);
                                        break;
                                    case 2:
                                        delete(i);
                                        break;
                                }
                                dialog.dismiss();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();

                return true;
            }
        });
        listVIew.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                golook(position);
            }
        });

        iv_add.setOnClickListener(this);
        empty_view.setOnClickListener(this);
        tv_type1.setOnClickListener(this);
        tv_type2.setOnClickListener(this);
        tv_type3.setOnClickListener(this);
        tv_type4.setOnClickListener(this);
        tv_type5.setOnClickListener(this);
        tv_type6.setOnClickListener(this);
        tv_type7.setOnClickListener(this);
        tv_type8.setOnClickListener(this);
        tv_type9.setOnClickListener(this);
    }

    private void golook(int pos) {
        Intent intent = new Intent();
        intent.putExtra("id", lists.get(pos).getId());
        intent.setClass(MainActivity.this, LookActivity.class);
        startActivity(intent);

    }

    private void gochang(int pos) {
        Intent intent = new Intent();
        intent.putExtra("id", lists.get(pos).getId());
        intent.setClass(MainActivity.this, AddActivity.class);
        startActivity(intent);

    }

    private void delete(int pos) {
        db.delete(lists.get(pos).getId());
        lists.remove(pos);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        init();
    }

    private long exitTime = 0;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((System.currentTimeMillis() - exitTime) > 2000) {
                Toast.makeText(getApplicationContext(), "Again Press To Quit", Toast.LENGTH_SHORT).show();
                exitTime = System.currentTimeMillis();
            } else {
                finish();
                System.exit(0);
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    class NoteAdapter extends BaseAdapter {

        private List<NoteBean> noteBeans;

        public void setNoteBeans(List<NoteBean> noteBeans) {
            this.noteBeans = noteBeans;
        }

        @Override
        public int getCount() {
            return noteBeans.size();
        }

        @Override
        public Object getItem(int i) {
            return noteBeans.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            NoteBean bean = noteBeans.get(i);
            view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.list_view, null);
            TextView tv_title = (TextView) view.findViewById(R.id.tv_title);
            TextView tv_date = (TextView) view.findViewById(R.id.tv_date);
            TextView tv_time = (TextView) view.findViewById(R.id.tv_time);
            tv_title.setText(bean.getTitle());
            tv_date.setText(bean.getDate());
            tv_time.setText(bean.getTime());
            return view;

        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_add:
                startActivity(new Intent().setClass(MainActivity.this,
                        AddActivity.class));
                break;
            case R.id.empty_view:
                startActivity(new Intent().setClass(MainActivity.this,
                        AddActivity.class));
                break;
            default:
                TextView tv = (TextView)view;
                lists.clear();
                lists.addAll(db.getListsByType(tv.getText().toString()));
                adapter.notifyDataSetChanged();
                break;
        }
    }
}
