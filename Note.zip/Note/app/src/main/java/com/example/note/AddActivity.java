package com.example.note;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.note.bean.NoteBean;
import com.example.note.util.DataBaseHelper;
import com.example.note.widget.TypePopup;

public class AddActivity extends Activity implements OnClickListener {

    private TextView tv_banner_title;
    private TextView tv_date;
    private TextView tv_time;
    private TextView tv_add_type;
    LinearLayout ll_styles;
    private EditText et_title;
    private EditText et_content;
    private Button bt_save;
    private ImageView iv_back;
    private DataBaseHelper db = null;
    boolean flag = true;
    String id = null;
    String[] split;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    TypePopup popup;
    private Button add_pic;
    private GridView image_grid_view;
    private List<String> datas = new ArrayList<>();
    private GridViewAdapter adapter;

    public static final int REQUEST_CODE_GET_PHOTO = 1;
    private static final int PICK_IMAGE_ACTIVITY_REQUEST_CODE = 200;

    private String path;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_activity);
        initView();
        initListener();
        initData();
    }

    private void initView() {
        tv_banner_title = (TextView) findViewById(R.id.tv_banner_title);
        tv_date = (TextView) findViewById(R.id.tv_date);
        tv_time = (TextView) findViewById(R.id.tv_time);
        et_title = (EditText) findViewById(R.id.et_title);
        tv_add_type = (TextView) findViewById(R.id.tv_add_type);
        ll_styles = (LinearLayout) findViewById(R.id.ll_styles);
        et_content = (EditText) findViewById(R.id.et_content);
        bt_save = (Button) findViewById(R.id.bt_save);
        iv_back = (ImageView) findViewById(R.id.iv_back);

        add_pic = (Button) findViewById(R.id.add_pic);
        image_grid_view = (GridView) findViewById(R.id.image_grid_view);
        adapter = new GridViewAdapter();
        image_grid_view.setAdapter(adapter);
        popup = new TypePopup(this);
        popup.setTypeClick(click);
    }

    private void initData() {
        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        if (id != null) {
            tv_banner_title.setText("Update Note");
            add_pic.setVisibility(View.GONE);
            flag = false;
            db = new DataBaseHelper(AddActivity.this);
            NoteBean note = db.getNote(id);
            et_title.setText(note.getTitle());
            et_content.setText(note.getContent());
            List<String> pics = note.getPics();
            for (int i = 0; i < pics.size(); i++) {
                datas.add(pics.get(i));
                adapter.notifyDataSetChanged();
            }
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((datas.size()+1)*200, ViewGroup.LayoutParams.WRAP_CONTENT);
            image_grid_view.setLayoutParams(params);
            image_grid_view.setNumColumns((datas.size()));
        } else {
            tv_banner_title.setText("Add New Note");
        }
    }

    private void initListener() {

        split = sdf.format(new Date()).split(" ");
        tv_date.setText(split[0]);
        tv_time.setText(split[1]);
        bt_save.setOnClickListener(this);
        iv_back.setOnClickListener(this);
        add_pic.setOnClickListener(this);

        tv_add_type.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_save:
                db = new DataBaseHelper(AddActivity.this);
                NoteBean bean = new NoteBean(id, et_title.getText().toString(), et_content.getText().toString(),
                        tv_date.getText().toString(), tv_time.getText().toString());
                bean.setPics(datas);
                int count = ll_styles.getChildCount();
                if (count > 0) {
                    List<String> types = new ArrayList<>();
                    for (int i = 0; i < count; i++) {
                        TextView viewType = (TextView) ll_styles.getChildAt(i);
                        types.add(viewType.getText().toString());
                    }
                    bean.setTypes(types);
                }
                if (flag) {
                    db.add(bean);
                } else {
                    db.update(bean);
                }
                finish();
                break;
            case R.id.iv_back:
                finish();
                break;
            case R.id.add_pic:

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, PICK_IMAGE_ACTIVITY_REQUEST_CODE);
//
//                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                File file = new File(getMediaDir(), System.currentTimeMillis() + ".jpg");
//                if (!file.exists()) {
//                    try {
//                        file.createNewFile();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//                path = file.getAbsolutePath();
//                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(file));
//                startActivityForResult(intent, REQUEST_CODE_GET_PHOTO);

                break;
            case R.id.tv_add_type:
                if (null != this && this.getCurrentFocus() != null) {
                    if (null != getWindow()) {
                        getWindow().getDecorView().clearFocus();
                        InputMethodManager im = ((InputMethodManager) this.getApplicationContext().getSystemService(INPUT_METHOD_SERVICE));
                        if (null != im) {
                            im.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                        }
                    }
                }
                if (!popup.isShowing())
                    popup.showAsDropDown(tv_add_type, 0, 0, Gravity.CENTER);
                break;
        }
    }

    TypePopup.onTypeClick click = new TypePopup.onTypeClick() {
        @Override
        public void click(String str) {
            if (ll_styles.getChildCount() > 2) {
                Toast.makeText(getApplicationContext(), "You can add three marks almost!", Toast.LENGTH_SHORT).show();
                return;
            }
            TextView tv = new TextView(getApplicationContext());
            tv.setText(str);
            tv.setTextColor(Color.parseColor("#f3f3f3"));
            tv.setTextSize(18);
            tv.setPadding(10, 5, 10, 5);
            tv.setBackgroundResource(R.drawable.bg_gray);
            tv.setTextAppearance(getApplication(), R.style.mark_style_tmp);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.gravity = Gravity.CENTER;
            lp.setMargins(5, 5, 5, 5);
            tv.setLayoutParams(lp);
            ll_styles.addView(tv);
//            tv_type.setText(str);
//            tv_type.setVisibility(View.VISIBLE);
        }
    };

    public File getMediaDir() {
        File dir = new File(Environment.getExternalStorageDirectory(),
                "NotesMedia");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    public String getRealPathFromURI(Uri contentUri) {
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            // Do not call Cursor.close() on a cursor obtained using this method,
            // because the activity will do that for you at the appropriate time
            Cursor cursor = this.managedQuery(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } catch (Exception e) {
            return contentUri.getPath();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        System.out.println(data);

        switch (requestCode) {
            case REQUEST_CODE_GET_PHOTO:
                if (resultCode == RESULT_OK) {
                    datas.add(path);
                    adapter.notifyDataSetChanged();
                }
                break;
            case PICK_IMAGE_ACTIVITY_REQUEST_CODE:
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    if (uri != null) {
                        String realPath = getRealPathFromURI(uri);
                        if (new File(realPath).length() > 300 * 1024 || datas.size() >= 3) {
                            Toast.makeText(this, "PIC is to large OR You have add Three Pic", Toast.LENGTH_SHORT).show();
                        } else {
                            datas.add(realPath);
                            adapter.notifyDataSetChanged();
                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((datas.size()+1)*200, ViewGroup.LayoutParams.WRAP_CONTENT);
                            image_grid_view.setLayoutParams(params);
                            image_grid_view.setNumColumns((datas.size()));
                        }

                    } else {
                    }
                }
                break;
            default:
                break;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }


    private class GridViewAdapter extends BaseAdapter {
        private ViewHolder mViewHolder;


        @Override
        public int getCount() {
            return datas.size();
        }

        @Override
        public Object getItem(int position) {
            return datas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pic_item, parent, false);
                mViewHolder = new ViewHolder();
                mViewHolder.mImageView = (ImageView) convertView.findViewById(R.id.imageView);
                convertView.setTag(mViewHolder);
            } else {
                mViewHolder = (ViewHolder) convertView.getTag();
            }

            mViewHolder.mImageView.setImageURI(Uri.fromFile(new File(datas.get(position))));
//            mViewHolder.mImageView.setImageBitmap(mBitmaps.get(position));
            return convertView;
        }

        public class ViewHolder {
            public ImageView mImageView;
        }
    }
}
