package com.example.note.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.note.bean.NoteBean;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final String Database = "notedata";
    private static final int version = 1;

    public DataBaseHelper(Context context) {
        super(context, Database, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table notes(id integer primary key autoincrement not null, date varchar(12),time varchar(12),title varchar(20),content nvarchar(50)) ";
        String picsql = "create table dataimg(id integer primary key autoincrement not null,mid integer not null, imgurl varchar(100)) ";
        String typeSql = "create table types(id integer primary key autoincrement not null,mid integer not null, typename varchar(100)) ";
        db.execSQL(sql);
        db.execSQL(picsql);
        db.execSQL(typeSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public void add(NoteBean bean) {
        Log.e("acci", bean.toString());
        SQLiteDatabase sqldata = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", bean.getDate());
        values.put("time", bean.getTime());
        values.put("title", bean.getTitle());
        values.put("content", bean.getContent());
        sqldata.insert("notes", null, values);
        Cursor query = sqldata.rawQuery("select MAX(id) as maxid from notes", null);
        while (query.moveToNext()) {
            String id = query.getString(query.getColumnIndex("maxid"));
            List<String> pics = bean.getPics();
            if (pics != null)
                for (int i = 0; i < pics.size(); i++) {
                    ContentValues val = new ContentValues();
                    val.put("mid", id);
                    val.put("imgurl", pics.get(i));
                    sqldata.insert("dataimg", null, val);
                }
            List<String> types = bean.getTypes();
            if (types != null)
                for (int i = 0; i < types.size(); i++) {
                    ContentValues val = new ContentValues();
                    val.put("mid", id);
                    val.put("typename", types.get(i));
                    sqldata.insert("types", null, val);
                }
        }
    }

    public void update(NoteBean bean) {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", bean.getDate());
        values.put("time", bean.getTime());
        values.put("title", bean.getTitle());
        values.put("content", bean.getContent());
        database.update("notes", values, "id=?", new String[]{bean.getId()});
        database.delete("dataimg", "mid=?", new String[]{bean.getId()});
        List<String> pics = bean.getPics();
        for (int i = 0; i < pics.size(); i++) {
            ContentValues val = new ContentValues();
            val.put("mid", bean.getId());
            val.put("imgurl", pics.get(i));
            database.insert("dataimg", null, val);
        }
    }

    public void delete(String id) {
        SQLiteDatabase database = getWritableDatabase();
        database.delete("notes", "id=?", new String[]{id});
        database.delete("dataimg", "mid=?", new String[]{id});
        database.delete("types", "mid=?", new String[]{id});
    }

    public NoteBean getNote(String id) {
        NoteBean bean = null;

        SQLiteDatabase database = getWritableDatabase();
        Cursor cur = database.query("notes", null, "id=?", new String[]{id}, null, null, null);
        while (cur.moveToNext()) {
            String title = cur.getString(cur.getColumnIndex("title"));
            String content = cur.getString(cur.getColumnIndex("content"));
            String date = cur.getString(cur.getColumnIndex("date"));
            String time = cur.getString(cur.getColumnIndex("time"));
            bean = new NoteBean(id, title, content, date, time);
            List<String> pics = new ArrayList<>();
            Cursor cursor = database.query("dataimg", null, "mid=?",
                    new String[]{id}, null, null, null);
            while (cursor.moveToNext()) {
                pics.add(cursor.getString(cursor.getColumnIndex("imgurl")));
            }
            bean.setPics(pics);

            List<String> types = new ArrayList<>();
            Cursor cursorType = database.query("types", null, "mid=?",
                    new String[]{id}, null, null, null);
            while (cursorType.moveToNext()) {
                types.add(cursorType.getString(cursorType.getColumnIndex("typename")));
            }
            bean.setTypes(types);
        }
        return bean;
    }

    public List<NoteBean> getLists() {
        List<NoteBean> lists = new ArrayList<>();
        SQLiteDatabase database = getWritableDatabase();
        Cursor cur = database.query("notes", null, null, null, null, null, null);
        while (cur.moveToNext()) {
            String id = cur.getString(cur.getColumnIndex("id"));
            String title = cur.getString(cur.getColumnIndex("title"));
            String date = cur.getString(cur.getColumnIndex("date"));
            String time = cur.getString(cur.getColumnIndex("time"));
            NoteBean bean = new NoteBean(id, title, date, time);
            lists.add(bean);
        }
        return lists;
    }

    public List<NoteBean> getListsByType(String type) {
        List<NoteBean> notes = new ArrayList<>();
        SQLiteDatabase database = getWritableDatabase();
        Cursor cur = database.query("types", new String[]{"mid"}, "typename=?", new String[]{type}, null, null, null);
        while (cur.moveToNext()) {
            String id = cur.getString(cur.getColumnIndex("mid"));
            notes.add(getNote(id));
        }
        return notes;
    }
}
